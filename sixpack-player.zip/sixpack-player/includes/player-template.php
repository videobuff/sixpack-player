<?php
defined('ABSPATH') || exit;
// Vars available: $s (settings array)
// JS handles rendering via splData (wp_localize_script)
?>
<div id="sixpackPlayerRoot"></div>
