<?php
defined('ABSPATH') || exit;

add_action('admin_menu', 'spl_admin_menu');
add_action('admin_init', 'spl_save_settings');
add_action('admin_enqueue_scripts', 'spl_admin_assets');

function spl_admin_menu() {
    add_menu_page(
        'Sixpack Player',
        'Sixpack Player',
        'manage_options',
        'sixpack-player',
        'spl_admin_page',
        'dashicons-format-audio',
        60
    );
}

function spl_admin_assets($hook) {
    if ($hook !== 'toplevel_page_sixpack-player') return;
    wp_enqueue_media();
    wp_enqueue_style('wp-color-picker');
    wp_enqueue_script('wp-color-picker');
    wp_enqueue_style('sixpack-admin', SPL_URL . 'assets/admin.css', [], SPL_VERSION);
    wp_enqueue_script('jquery-ui-sortable');
    wp_enqueue_script('sixpack-admin', SPL_URL . 'assets/admin.js', ['jquery', 'jquery-ui-sortable', 'wp-color-picker'], SPL_VERSION, true);
}

function spl_save_settings() {
    if (!isset($_POST['spl_nonce']) || !wp_verify_nonce($_POST['spl_nonce'], 'spl_save')) return;
    if (!current_user_can('manage_options')) return;

    $data = [
        'title'           => sanitize_text_field($_POST['spl_title'] ?? ''),
        'subtitle'        => sanitize_text_field($_POST['spl_subtitle'] ?? ''),
        'accent'          => sanitize_hex_color($_POST['spl_accent'] ?? '#e8c14a'),
        'default_artwork' => esc_url_raw($_POST['spl_default_artwork'] ?? ''),
        'tracks'          => [],
    ];

    $titles   = $_POST['track_title']    ?? [];
    $subs     = $_POST['track_sub']      ?? [];
    $srcs     = $_POST['track_src']      ?? [];
    $artworks = $_POST['track_artwork']  ?? [];
    $dlnames  = $_POST['track_dlname']   ?? [];

    foreach ($titles as $i => $title) {
        if (empty($srcs[$i])) continue; // skip rows without audio
        $data['tracks'][] = [
            'title'   => sanitize_text_field($title),
            'sub'     => sanitize_text_field($subs[$i] ?? ''),
            'src'     => esc_url_raw($srcs[$i]),
            'artwork' => esc_url_raw($artworks[$i] ?? ''),
            'dlname'  => sanitize_file_name($dlnames[$i] ?? ''),
        ];
    }

    update_option(SPL_OPTION, $data);
    add_settings_error('spl', 'saved', '✓ Instellingen opgeslagen.', 'success');
}

function spl_admin_page() {
    $s      = spl_get_settings();
    $tracks = $s['tracks'] ?? [];
    settings_errors('spl');
    ?>
    <div class="wrap spl-wrap">
      <h1 class="spl-page-title">🎸 Sixpack Player</h1>
      <form method="post" id="splForm">
        <?php wp_nonce_field('spl_save', 'spl_nonce'); ?>

        <!-- ── ALGEMENE INSTELLINGEN ── -->
        <div class="spl-card">
          <h2>Algemene instellingen</h2>
          <div class="spl-grid-2">
            <div class="spl-field">
              <label>Titel</label>
              <input type="text" name="spl_title" value="<?= esc_attr($s['title'] ?? 'SIXPACK') ?>">
            </div>
            <div class="spl-field">
              <label>Subtitel</label>
              <input type="text" name="spl_subtitle" value="<?= esc_attr($s['subtitle'] ?? 'Live Recordings') ?>">
            </div>
            <div class="spl-field">
              <label>Accentkleur</label>
              <input type="text" name="spl_accent" id="spl_accent" value="<?= esc_attr($s['accent'] ?? '#e8c14a') ?>" class="spl-color">
            </div>
            <div class="spl-field">
              <label>Standaard artwork</label>
              <div class="spl-media-row">
                <input type="text" name="spl_default_artwork" id="spl_default_artwork_url"
                       value="<?= esc_attr($s['default_artwork'] ?? '') ?>" placeholder="https://..." readonly>
                <button type="button" class="button spl-media-btn" data-target="spl_default_artwork_url" data-preview="spl_default_artwork_preview">
                  Kies afbeelding
                </button>
              </div>
              <?php if (!empty($s['default_artwork'])): ?>
                <img id="spl_default_artwork_preview" src="<?= esc_url($s['default_artwork']) ?>" class="spl-preview">
              <?php else: ?>
                <img id="spl_default_artwork_preview" src="" class="spl-preview spl-hidden">
              <?php endif; ?>
            </div>
          </div>
        </div>

        <!-- ── SHORTCODE ── -->
        <div class="spl-card spl-shortcode-card">
          <strong>Shortcode:</strong>
          <code>[sixpack_player]</code>
          <span class="spl-hint">Plak dit in een pagina of blok.</span>
        </div>

        <!-- ── TRACKLIST ── -->
        <div class="spl-card">
          <h2>Tracks
            <button type="button" class="button button-primary spl-add-track" id="splAddTrack">+ Track toevoegen</button>
          </h2>

          <div id="splTrackList" class="spl-tracklist">
            <?php foreach ($tracks as $i => $t): ?>
              <?php spl_track_row($t, $i); ?>
            <?php endforeach; ?>
            <?php if (empty($tracks)): ?>
              <p class="spl-empty" id="splEmpty">Nog geen tracks. Klik op "+ Track toevoegen".</p>
            <?php endif; ?>
          </div>
        </div>

        <div class="spl-save-bar">
          <?php submit_button('Opslaan', 'primary large', 'submit', false); ?>
        </div>
      </form>
    </div>

    <!-- ── TRACK ROW TEMPLATE (hidden) ── -->
    <script type="text/html" id="splTrackTemplate">
      <?php spl_track_row(['title'=>'','sub'=>'','src'=>'','artwork'=>'','dlname'=>''], '__IDX__'); ?>
    </script>
    <?php
}

function spl_track_row(array $t, $idx) {
    $i = $idx === '__IDX__' ? '__IDX__' : (int)$idx;
    ?>
    <div class="spl-track-row" data-idx="<?= $i ?>">
      <div class="spl-track-handle" title="Slepen om te sorteren">☰</div>

      <div class="spl-track-fields">
        <div class="spl-grid-3">
          <div class="spl-field">
            <label>Titel</label>
            <input type="text" name="track_title[<?= $i ?>]" value="<?= esc_attr($t['title'] ?? '') ?>" placeholder="Naam van het nummer">
          </div>
          <div class="spl-field">
            <label>Subtitel / venue</label>
            <input type="text" name="track_sub[<?= $i ?>]" value="<?= esc_attr($t['sub'] ?? '') ?>" placeholder="Ahoy · 12 okt 2024">
          </div>
          <div class="spl-field">
            <label>Download bestandsnaam</label>
            <input type="text" name="track_dlname[<?= $i ?>]" value="<?= esc_attr($t['dlname'] ?? '') ?>" placeholder="Sixpack-Track-Live.mp3">
          </div>
        </div>

        <div class="spl-grid-2">
          <div class="spl-field">
            <label>Audio (MP3)</label>
            <div class="spl-media-row">
              <input type="text" name="track_src[<?= $i ?>]"
                     class="spl-src-url" value="<?= esc_attr($t['src'] ?? '') ?>" placeholder="URL..." readonly>
              <button type="button" class="button spl-media-btn spl-audio-btn" data-type="audio">
                Kies MP3
              </button>
            </div>
          </div>
          <div class="spl-field">
            <label>Artwork</label>
            <div class="spl-media-row">
              <input type="text" name="track_artwork[<?= $i ?>]"
                     class="spl-art-url" value="<?= esc_attr($t['artwork'] ?? '') ?>" placeholder="URL..." readonly>
              <button type="button" class="button spl-media-btn spl-art-btn" data-type="image">
                Kies afbeelding
              </button>
              <?php if (!empty($t['artwork'])): ?>
                <img src="<?= esc_url($t['artwork']) ?>" class="spl-preview">
              <?php else: ?>
                <img src="" class="spl-preview spl-hidden">
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>

      <button type="button" class="spl-remove-track" title="Verwijder track">✕</button>
    </div>
    <?php
}
