<?php
/**
 * Sixpack Player – GitHub Updater
 * Checkt GitHub Releases op nieuwe versies en koppelt aan WP update-systeem.
 */
defined('ABSPATH') || exit;

class SPL_GitHub_Updater {

    private string $slug;
    private string $plugin_file;
    private string $current_version;
    private string $github_user;
    private string $github_repo;
    private string $api_url;
    private string $cache_key;
    private int    $cache_hours = 12;

    public function __construct(string $plugin_file, string $github_user, string $github_repo) {
        $this->plugin_file     = $plugin_file;
        $this->slug            = plugin_basename($plugin_file);
        $this->current_version = SPL_VERSION;
        $this->github_user     = $github_user;
        $this->github_repo     = $github_repo;
        $this->api_url         = "https://api.github.com/repos/{$github_user}/{$github_repo}/releases/latest";
        $this->cache_key       = 'spl_github_update_' . md5($this->api_url);

        add_filter('pre_set_site_transient_update_plugins', [$this, 'check_update']);
        add_filter('plugins_api',                           [$this, 'plugin_info'], 10, 3);
        add_filter('upgrader_post_install',                 [$this, 'after_install'], 10, 3);
    }

    /* ── FETCH RELEASE DATA (cached) ── */
    private function get_release(): ?object {
        $cached = get_transient($this->cache_key);
        if ($cached !== false) return $cached ?: null;

        $response = wp_remote_get($this->api_url, [
            'headers' => [
                'Accept'     => 'application/vnd.github+json',
                'User-Agent' => 'WordPress/' . get_bloginfo('version'),
            ],
            'timeout' => 10,
        ]);

        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            set_transient($this->cache_key, false, HOUR_IN_SECONDS);
            return null;
        }

        $release = json_decode(wp_remote_retrieve_body($response));
        set_transient($this->cache_key, $release, $this->cache_hours * HOUR_IN_SECONDS);
        return $release;
    }

    /* ── FIND ZIP ASSET IN RELEASE ── */
    private function get_zip_url(object $release): string {
        // Prefer an uploaded zip asset over the auto-generated source zip
        foreach ($release->assets ?? [] as $asset) {
            if (str_ends_with($asset->name, '.zip')) {
                return $asset->browser_download_url;
            }
        }
        // Fallback: GitHub auto-generated source zip
        return $release->zipball_url ?? '';
    }

    /* ── INJECT INTO WP UPDATE TRANSIENT ── */
    public function check_update(object $transient): object {
        if (empty($transient->checked)) return $transient;

        $release = $this->get_release();
        if (!$release) return $transient;

        $remote_version = ltrim($release->tag_name ?? '', 'v');

        if (version_compare($remote_version, $this->current_version, '>')) {
            $transient->response[$this->slug] = (object) [
                'slug'        => dirname($this->slug),
                'plugin'      => $this->slug,
                'new_version' => $remote_version,
                'url'         => "https://github.com/{$this->github_user}/{$this->github_repo}",
                'package'     => $this->get_zip_url($release),
                'icons'       => [],
                'banners'     => [],
                'tested'      => '6.7',
                'requires'    => '6.0',
            ];
        }

        return $transient;
    }

    /* ── PLUGIN INFO POPUP ── */
    public function plugin_info(mixed $result, string $action, object $args): mixed {
        if ($action !== 'plugin_information') return $result;
        if (($args->slug ?? '') !== dirname($this->slug)) return $result;

        $release = $this->get_release();
        if (!$release) return $result;

        $remote_version = ltrim($release->tag_name ?? '', 'v');

        return (object) [
            'name'          => 'Sixpack Player',
            'slug'          => dirname($this->slug),
            'version'       => $remote_version,
            'author'        => 'Sixpack',
            'homepage'      => "https://github.com/{$this->github_user}/{$this->github_repo}",
            'download_link' => $this->get_zip_url($release),
            'tested'        => '6.7',
            'requires'      => '6.0',
            'last_updated'  => $release->published_at ?? '',
            'sections'      => [
                'description' => 'Live recording MP3 player met admin playlist-beheer.',
                'changelog'   => nl2br(esc_html($release->body ?? 'Zie GitHub voor wijzigingen.')),
            ],
        ];
    }

    /* ── RENAME UNZIPPED FOLDER (GitHub zip heeft raar mapnaam) ── */
    public function after_install(bool|WP_Error $response, array $hook_extra, array $result): bool|WP_Error {
        if (is_wp_error($response)) return $response;
        if (($hook_extra['plugin'] ?? '') !== $this->slug) return $response;

        global $wp_filesystem;
        $target = WP_PLUGIN_DIR . '/' . dirname($this->slug);
        $wp_filesystem->move($result['destination'], $target, true);
        $result['destination'] = $target;

        // Clear cache so next check fetches fresh data
        delete_transient($this->cache_key);

        activate_plugin($this->slug);
        return $response;
    }

    /* ── FORCE CHECK (handig voor debug) ── */
    public function clear_cache(): void {
        delete_transient($this->cache_key);
    }
}
