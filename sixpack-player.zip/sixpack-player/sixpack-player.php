<?php
/**
 * Plugin Name: Sixpack Player
 * Description: Live recording MP3 player met admin playlist-beheer.
 * Version:     1.0.0
 * Author:      Sixpack
 * Text Domain: sixpack-player
 */

defined('ABSPATH') || exit;

define('SPL_VERSION', '1.0.0');
define('SPL_DIR',     plugin_dir_path(__FILE__));
define('SPL_URL',     plugin_dir_url(__FILE__));
define('SPL_OPTION',  'sixpack_player_settings');

/* ── GITHUB UPDATER ─────────────────────────────────────
 *  ▶ Vul hieronder je eigen GitHub gebruikersnaam en repo in.
 *     De repo moet Public zijn én releases hebben als GitHub Release
 *     met een .zip als attached asset.
 * ─────────────────────────────────────────────────────── */
define('SPL_GITHUB_USER', 'JOUW-GITHUB-NAAM');   // ← aanpassen
define('SPL_GITHUB_REPO', 'sixpack-player');      // ← repo naam

require_once SPL_DIR . 'includes/class-github-updater.php';
new SPL_GitHub_Updater(__FILE__, SPL_GITHUB_USER, SPL_GITHUB_REPO);

/* ── ADMIN ─────────────────────────────────────────────── */
if (is_admin()) {
    require_once SPL_DIR . 'includes/admin.php';
}

/* ── SHORTCODE  [sixpack_player] ────────────────────────── */
add_shortcode('sixpack_player', 'spl_render_player');

function spl_render_player() {
    $s = spl_get_settings();
    ob_start();
    require SPL_DIR . 'includes/player-template.php';
    return ob_get_clean();
}

/* ── FRONTEND ASSETS ────────────────────────────────────── */
add_action('wp_enqueue_scripts', 'spl_frontend_assets');

function spl_frontend_assets() {
    global $post;
    if (!is_a($post, 'WP_Post') || !has_shortcode($post->post_content, 'sixpack_player')) return;

    wp_enqueue_style('sixpack-player', SPL_URL . 'assets/player.css', [], SPL_VERSION);
    wp_enqueue_script('sixpack-player', SPL_URL . 'assets/player.js', [], SPL_VERSION, true);

    $s = spl_get_settings();
    wp_localize_script('sixpack-player', 'splData', [
        'tracks' => $s['tracks'] ?? [],
        'config' => [
            'title'          => $s['title']          ?? 'SIXPACK',
            'subtitle'       => $s['subtitle']       ?? 'Live Recordings',
            'accent'         => $s['accent']         ?? '#e8c14a',
            'defaultArtwork' => $s['default_artwork'] ?? '',
        ],
    ]);
}

/* ── HELPERS ────────────────────────────────────────────── */
function spl_get_settings(): array {
    return (array) get_option(SPL_OPTION, [
        'title'           => 'SIXPACK',
        'subtitle'        => 'Live Recordings',
        'accent'          => '#e8c14a',
        'default_artwork' => '',
        'tracks'          => [],
    ]);
}
