/* Sixpack Player – player.js */
(function () {
  const { tracks, config } = window.splData || {};
  if (!tracks || !tracks.length) return;

  const root = document.getElementById('sixpackPlayerRoot');
  if (!root) return;

  /* apply accent color from config */
  if (config.accent) {
    root.style.setProperty('--accent', config.accent);
  }

  const audio = new Audio();
  let cur = 0, playing = false;

  /* ── ICONS ── */
  const I = {
    play:  `<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>`,
    pause: `<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>`,
    prev:  `<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M6 6h2v12H6zm3.5 6 8.5 6V6z"/></svg>`,
    next:  `<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="m6 18 8.5-6L6 6v12zm2.5-6 8.5 6V6l-8.5 6zm7-6h2v12h-2z"/></svg>`,
    vol:   `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02z"/></svg>`,
    dl:    `<svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M19 9h-4V3H9v6H5l7 7 7-7zm-8 2V5h2v6h1.17L12 13.17 9.83 11H11zm-6 7h14v2H5z"/></svg>`,
  };

  function fmt(s) {
    if (!s || isNaN(s)) return '–:––';
    return Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');
  }

  function art(t) { return t.artwork || config.defaultArtwork || ''; }

  /* ── BUILD HTML ── */
  const t0 = tracks[0];
  root.innerHTML = `
    <div class="sp-wrap">
      <div class="sp-header">
        <h1>${config.title} <span>Live</span></h1>
        <p>${config.subtitle}</p>
      </div>

      <div class="sp-card">
        <div class="sp-artwork">
          <img id="spArt" src="${art(t0)}" alt="artwork">
        </div>
        <div class="sp-info">
          <div>
            <div class="sp-title" id="spTitle">${t0.title}</div>
            <div class="sp-sub"   id="spSub">${t0.sub || ''}</div>
          </div>
          <div class="sp-prog-wrap">
            <div class="sp-time-row"><span id="spCur">0:00</span><span id="spDur">–:––</span></div>
            <input type="range" class="sp-range" id="spProg" min="0" max="100" value="0">
          </div>
          <div class="sp-controls">
            <button class="sp-btn" id="spPrev">${I.prev}</button>
            <button class="sp-btn sp-btn-play" id="spPlay">${I.play}</button>
            <button class="sp-btn" id="spNext">${I.next}</button>
            <div class="sp-vol-wrap">${I.vol}<input type="range" class="sp-vol" id="spVol" min="0" max="1" step="0.01" value="0.8"></div>
            <a class="sp-dl" id="spDl" href="${t0.src}" download="${t0.dlname || ''}">
              ${I.dl} Download
            </a>
          </div>
        </div>
      </div>

      <div class="sp-playlist">
        <div class="sp-pl-head">Setlist</div>
        <div id="spList"></div>
      </div>
    </div>`;

  /* ── PLAYLIST ── */
  const list = document.getElementById('spList');
  list.innerHTML = tracks.map((t, i) => `
    <div class="sp-item${i === 0 ? ' active' : ''}" data-i="${i}">
      <div class="sp-item-thumb"><img src="${art(t)}" alt="${t.title}" loading="lazy"></div>
      <div class="sp-item-meta">
        <div class="sp-item-title">${t.title}</div>
        <div class="sp-item-sub">${t.sub || ''}</div>
      </div>
      <div class="sp-item-right">
        <span class="sp-item-dur" id="sDur${i}">–:––</span>
        <a class="sp-item-dl" href="${t.src}" download="${t.dlname || ''}" title="Download" onclick="event.stopPropagation()">${I.dl}</a>
        <div class="sp-item-right">
          <div class="sp-eq"><span></span><span></span><span></span></div>
          <span class="sp-item-num">${i + 1}</span>
        </div>
      </div>
    </div>`).join('');

  list.querySelectorAll('.sp-item').forEach(el => {
    el.addEventListener('click', () => load(+el.dataset.i, true));
  });

  /* preload durations */
  tracks.forEach((t, i) => {
    const tmp = new Audio();
    tmp.src = t.src;
    tmp.addEventListener('loadedmetadata', () => {
      const el = document.getElementById('sDur' + i);
      if (el) el.textContent = fmt(tmp.duration);
    });
  });

  /* ── LOAD TRACK ── */
  function load(idx, play) {
    cur = idx;
    const t = tracks[idx];
    document.getElementById('spArt').src   = art(t);
    document.getElementById('spTitle').textContent = t.title;
    document.getElementById('spSub').textContent   = t.sub || '';
    document.getElementById('spProg').value = 0;
    document.getElementById('spCur').textContent = '0:00';
    document.getElementById('spDur').textContent = '–:––';
    const dl = document.getElementById('spDl');
    dl.href = t.src; dl.download = t.dlname || '';

    audio.src = t.src; audio.load();

    list.querySelectorAll('.sp-item').forEach((el, i) => {
      el.classList.toggle('active', i === idx);
      el.classList.remove('playing');
    });

    if (play) { audio.play(); playing = true; }
    else playing = false;
    syncBtn();
  }

  /* ── SYNC PLAY BTN ── */
  function syncBtn() {
    document.getElementById('spPlay').innerHTML = playing ? I.pause : I.play;
    const active = list.querySelector('.sp-item.active');
    if (active) active.classList.toggle('playing', playing);
  }

  /* ── EVENTS ── */
  document.getElementById('spPlay').addEventListener('click', () => {
    playing ? audio.pause() : audio.play();
    playing = !playing;
    syncBtn();
  });
  document.getElementById('spPrev').addEventListener('click', () => {
    if (audio.currentTime > 3) { audio.currentTime = 0; return; }
    load((cur - 1 + tracks.length) % tracks.length, playing);
  });
  document.getElementById('spNext').addEventListener('click', () => {
    load((cur + 1) % tracks.length, playing);
  });

  const prog = document.getElementById('spProg');
  prog.addEventListener('input', () => {
    if (audio.duration) audio.currentTime = (prog.value / 100) * audio.duration;
  });

  document.getElementById('spVol').addEventListener('input', function () { audio.volume = +this.value; });
  audio.volume = 0.8;

  audio.addEventListener('timeupdate', () => {
    if (!audio.duration) return;
    const p = (audio.currentTime / audio.duration) * 100;
    prog.value = p;
    prog.style.setProperty('--p', p + '%');
    document.getElementById('spCur').textContent = fmt(audio.currentTime);
  });
  audio.addEventListener('loadedmetadata', () => {
    document.getElementById('spDur').textContent = fmt(audio.duration);
  });
  audio.addEventListener('ended', () => load((cur + 1) % tracks.length, true));
})();
