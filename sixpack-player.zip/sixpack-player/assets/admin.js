/* Sixpack Player – admin.js */
jQuery(function ($) {

  /* ── COLOR PICKER ── */
  $('#spl_accent').wpColorPicker();

  /* ── SORTABLE TRACKS ── */
  $('#splTrackList').sortable({
    handle:      '.spl-track-handle',
    placeholder: 'spl-track-row ui-sortable-placeholder',
    tolerance:   'pointer',
    update: reindex
  });

  /* ── ADD TRACK ── */
  $('#splAddTrack').on('click', function () {
    $('#splEmpty').remove();
    const idx  = Date.now(); // unique temp index
    const tmpl = $('#splTrackTemplate').html().replaceAll('__IDX__', idx);
    $('#splTrackList').append(tmpl);
    reindex();
  });

  /* ── REMOVE TRACK ── */
  $(document).on('click', '.spl-remove-track', function () {
    $(this).closest('.spl-track-row').remove();
    reindex();
    if ($('.spl-track-row').length === 0) {
      $('#splTrackList').append('<p class="spl-empty" id="splEmpty">Nog geen tracks. Klik op "+ Track toevoegen".</p>');
    }
  });

  /* ── MEDIA UPLOADER – global default artwork ── */
  $(document).on('click', '.spl-media-btn[data-target]', function (e) {
    e.preventDefault();
    const targetId  = $(this).data('target');
    const previewId = $(this).data('preview');
    const type      = $(this).data('type') || 'image';
    openMedia(type, function (url) {
      $('#' + targetId).val(url);
      const $prev = $('#' + previewId);
      $prev.attr('src', url).removeClass('spl-hidden');
    });
  });

  /* ── MEDIA UPLOADER – track audio ── */
  $(document).on('click', '.spl-audio-btn', function (e) {
    e.preventDefault();
    const $row = $(this).closest('.spl-track-row');
    openMedia('audio', function (url) {
      $row.find('.spl-src-url').val(url);
    });
  });

  /* ── MEDIA UPLOADER – track artwork ── */
  $(document).on('click', '.spl-art-btn', function (e) {
    e.preventDefault();
    const $row = $(this).closest('.spl-track-row');
    openMedia('image', function (url) {
      $row.find('.spl-art-url').val(url);
      const $prev = $row.find('.spl-preview');
      $prev.attr('src', url).removeClass('spl-hidden');
    });
  });

  /* ── HELPERS ── */
  function openMedia(type, cb) {
    let frame;
    const opts = {
      title:    type === 'audio' ? 'Kies MP3' : 'Kies afbeelding',
      button:   { text: 'Gebruik dit bestand' },
      multiple: false,
    };
    if (type === 'audio') opts.library = { type: 'audio' };

    frame = wp.media(opts);
    frame.on('select', function () {
      const att = frame.state().get('selection').first().toJSON();
      cb(att.url);
    });
    frame.open();
  }

  function reindex() {
    $('.spl-track-row').each(function (i) {
      $(this).attr('data-idx', i);
      $(this).find('input[name^="track_"]').each(function () {
        const name = $(this).attr('name').replace(/\[\d+\]/, '[' + i + ']');
        $(this).attr('name', name);
      });
    });
  }
});
